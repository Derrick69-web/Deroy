const searchContainer = document.getElementById("search-container");
const searchBtn = document.getElementById("search-btn");
const searchInput = document.getElementById("search-input");

// Expand/collapse on click
searchBtn.addEventListener("click", (e) => {
  if (!searchContainer.classList.contains("active")) {
    e.preventDefault(); // prevent submit/redirect
    searchContainer.classList.add("active");
    searchInput.focus();
  } else {
    const query = searchInput.value.trim();
    if (!query) {
      alert("Please type something to search!");
    } else {
      window.location.href = "search.html?q=" + encodeURIComponent(query);
    }
  }
});
