/* ---------- MENU DATA ----------
   Put your real images inside "images/" folder and match the filenames below.
   If an image file is missing, a placeholder will appear. */
const foodItems = [
  { name: "Jollof Rice", price: 30, image: "images/jrice.jpg" },
  { name: "Fried Rice", price: 30, image: "images/fried.jpg" },
  { name: "Banku with Stew", price: 20, image: "images/banku.png" },
  { name: "Waakye Special", price: 20, image: "images/Waakye Special.jpg" },
  { name: "Pastries", price: 20, image: "images/Pastries.png" },
  { name: "Beverages", price: 20, image: "images/Beverages.png" },
];


const placeholder = name =>
  `https://via.placeholder.com/300x200.png?text=${encodeURIComponent(name)}`;

const menuGrid = document.getElementById("menu-grid");
const cartModal = document.getElementById("cart-modal");
const cartItemsEl = document.getElementById("cart-items");
const cartTotalEl = document.getElementById("cart-total");
const cartBtn = document.getElementById("cart-btn");
const clearCartBtn = document.getElementById("clear-cart");
const closeCartBtn = document.getElementById("close-cart");

let cart = [];

/* Render menu cards */
function renderMenu() {
  menuGrid.innerHTML = '';
  foodItems.forEach((item, index) => {
    const imgSrc = item.image ? item.image : placeholder(item.name);
    const card = document.createElement('div');
    card.className = 'menu-item';
    card.innerHTML = `
      <img src="${imgSrc}" alt="${item.name}" loading="lazy"
           onerror="this.onerror=null;this.src='${placeholder('Image+Not+Found')}'">
      <h3>${item.name}</h3>
      <p>GHS${item.price.toFixed(2)}</p>
      <button class="add-btn" data-index="${index}">Add to Cart</button>
    `;
    menuGrid.appendChild(card);
  });
}

/* Add to cart (index is foodItems index) */
function addToCart(index) {
  const item = foodItems[index];
  if (!item) return;
  cart.push(item);
  updateCart();
}

/* Remove item by cart index */
function removeFromCart(i) {
  cart.splice(i, 1);
  updateCart();
}

/* Clear cart */
function clearCart() {
  cart = [];
  updateCart();
}

/* Update cart DOM */
function updateCart() {
  cartItemsEl.innerHTML = '';
  let total = 0;
  if (cart.length === 0) {
    cartItemsEl.innerHTML = '<li>Your cart is empty.</li>';
  } else {
    cart.forEach((item, i) => {
      total += item.price;
      const li = document.createElement('li');
      li.innerHTML = `
        <span>${item.name} - $${item.price.toFixed(2)}</span>
        <button class="remove-btn" data-index="${i}">❌</button>
      `;
      cartItemsEl.appendChild(li);
    });
  }
  cartTotalEl.textContent = total.toFixed(2);
}

/* Open/close cart */
function openCart() { cartModal.classList.remove('hidden'); }
function closeCart() { cartModal.classList.add('hidden'); }

/* Event delegation for add/remove buttons */
document.addEventListener('click', (e) => {
  const add = e.target.closest('.add-btn');
  if (add) {
    const idx = Number(add.dataset.index);
    addToCart(idx);
    return;
  }
  const rem = e.target.closest('.remove-btn');
  if (rem) {
    const idx = Number(rem.dataset.index);
    removeFromCart(idx);
    return;
  }
});

/* Attach UI button handlers */
if (cartBtn) cartBtn.addEventListener('click', openCart);
if (clearCartBtn) clearCartBtn.addEventListener('click', clearCart);
if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);

document.getElementById("login-btn").addEventListener("click", function() {
    window.location.href = "login.html"; // point to your login page
});


/* initial render */
renderMenu();
updateCart();